import mongoose from "mongoose";
const Schema = mongoose.Schema;

const profesionalSchema = new Schema({

    correo:{type:String, required:[true, 'Correo Obligatorio']},
    profesion:{type:String, requiered:[true, 'Profesion requerida']},
    ciudadOferta:String,
    fechaRegistro:{type:Date, default:Date.now}
})

// Convertir a modelo

const Profesion = mongoose.model('Profesion',profesionalSchema);

export default Profesion;